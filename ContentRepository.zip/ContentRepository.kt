package com.onya.app.data.repository

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.MetadataChanges
import com.onya.app.data.model.*
import com.onya.app.utils.Result
import com.onya.app.utils.safeApiCall
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ContentRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val cacheRepository: CacheRepository
) {
    
    companion object {
        private const val VIDEOS_COLLECTION = "videos"
        private const val SERIES_COLLECTION = "series"
        private const val EPISODES_COLLECTION = "episodes"
        private const val CATEGORIES_COLLECTION = "categories"
    }
    
    // Hybrid method to get series with episodes from both collections
    suspend fun getSeriesWithEpisodesFlow(): Flow<List<SeriesWithEpisodes>> = callbackFlow {
        try {
            // First try to get from /videos collection (new structure)
            val videosSnapshot = firestore.collection(VIDEOS_COLLECTION)
                .whereEqualTo("status", "published")
                .get()
                .await()
            
            if (videosSnapshot.documents.isNotEmpty()) {
                android.util.Log.d("ContentRepository", "Using /videos collection (${videosSnapshot.documents.size} videos)")
                
                val seriesWithEpisodes = videosSnapshot.documents.mapNotNull { doc ->
                    try {
                        val videoData = doc.data ?: return@mapNotNull null
                        val series = Series.fromFirestoreMap(videoData, doc.id)
                        val episode = Episode.fromFirestoreMap(videoData)
                        
                        SeriesWithEpisodes(
                            series = series,
                            episodes = listOf(episode)
                        )
                    } catch (e: Exception) {
                        android.util.Log.e("ContentRepository", "Failed to parse video ${doc.id}: ${e.message}")
                        null
                    }
                }
                
                trySend(seriesWithEpisodes)
                return@callbackFlow
            }
            
            // Fallback to /series + /episodes collections (old structure)
            android.util.Log.d("ContentRepository", "Falling back to /series + /episodes collections")
            
            val seriesSnapshot = firestore.collection(SERIES_COLLECTION)
                .whereEqualTo("isActive", true)
                .get()
                .await()
            
            val seriesWithEpisodes = seriesSnapshot.documents.mapNotNull { seriesDoc ->
                try {
                    val seriesData = seriesDoc.data ?: return@mapNotNull null
                    val series = Series.fromFirestoreMap(seriesData, seriesDoc.id)
                    
                    // Get episodes for this series
                    val episodesSnapshot = firestore.collection(EPISODES_COLLECTION)
                        .whereEqualTo("seriesId", seriesDoc.id)
                        .whereEqualTo("isActive", true)
                        .orderBy("episodeNumber", Query.Direction.ASCENDING)
                        .get()
                        .await()
                    
                    val episodes = episodesSnapshot.documents.mapNotNull { episodeDoc ->
                        try {
                            val episodeData = episodeDoc.data ?: return@mapNotNull null
                            Episode.fromFirestoreMap(episodeData)
                        } catch (e: Exception) {
                            android.util.Log.e("ContentRepository", "Failed to parse episode ${episodeDoc.id}: ${e.message}")
                            null
                        }
                    }
                    
                    SeriesWithEpisodes(
                        series = series,
                        episodes = episodes
                    )
                } catch (e: Exception) {
                    android.util.Log.e("ContentRepository", "Failed to parse series ${seriesDoc.id}: ${e.message}")
                    null
                }
            }
            
            trySend(seriesWithEpisodes)
            
        } catch (e: Exception) {
            android.util.Log.e("ContentRepository", "Error fetching series with episodes: ${e.message}")
            trySend(emptyList())
        }
    }

    // Get home page content with real-time updates
    fun getHomeContentFlow(): Flow<HomeContent> = callbackFlow {
        val listeners = mutableListOf<com.google.firebase.firestore.ListenerRegistration>()

        try {
            // Clear any cached content first
            currentHomeContent = HomeContent()
            android.util.Log.d("ContentRepository", "Cleared cached content, fetching fresh data")
            
            // Try to get content from /videos collection first (CMS primary collection)
            android.util.Log.d("ContentRepository", "Trying to fetch from /videos collection first")
            
                // Listen to videos collection (CMS primary collection) - check all content
                val videosListener = firestore.collection(VIDEOS_COLLECTION)
                    .orderBy("createdAt", Query.Direction.DESCENDING)
                    .limit(20)
                    .addSnapshotListener(MetadataChanges.INCLUDE) { snapshot, error ->
                    if (error != null) {
                        android.util.Log.e("ContentRepository", "Videos collection error: ${error.message}")
                        return@addSnapshotListener
                    }
                    
                    val allVideos = snapshot?.documents?.mapNotNull { doc ->
                        try {
                            doc.data?.let { Series.fromFirestoreMap(it, doc.id) }
                        } catch (e: Exception) {
                            android.util.Log.e("ContentRepository", "Failed to parse video ${doc.id}: ${e.message}")
                            null
                        }
                    } ?: emptyList()
                    
                    android.util.Log.d("ContentRepository", "Loaded ${allVideos.size} videos from /videos collection")
                    android.util.Log.d("ContentRepository", "Video titles: ${allVideos.map { it.title }}")
                    
                    if (allVideos.isNotEmpty()) {
                        // Split videos into different categories
                        val featuredSeries = allVideos.filter { it.isFeatured }.take(10)
                        val trendingShorts = allVideos.filter { it.isTrending }.take(20)
                        val newReleases = allVideos.filter { it.isNew }.take(15)
                        val premiumSeries = allVideos.filter { it.isPremium }.take(20)
                        
                        // Update home content
                        updateHomeContent(
                            featuredSeries = featuredSeries,
                            trendingShorts = trendingShorts,
                            newReleases = newReleases,
                            premiumSeries = premiumSeries
                        )
                        trySend(currentHomeContent)
                    }
                }
            listeners.add(videosListener)
            
                // Also try series collection as backup (check for both published and draft content)
                val seriesListener = firestore.collection(SERIES_COLLECTION)
                    .orderBy("createdAt", Query.Direction.DESCENDING)
                    .limit(20)
                    .addSnapshotListener(MetadataChanges.INCLUDE) { snapshot, error ->
                    if (error != null) {
                        android.util.Log.e("ContentRepository", "Series collection error: ${error.message}")
                        return@addSnapshotListener
                    }
                    
                    val allSeries = snapshot?.documents?.mapNotNull { doc ->
                        try {
                            doc.data?.let { Series.fromFirestoreMap(it, doc.id) }
                        } catch (e: Exception) {
                            android.util.Log.e("ContentRepository", "Failed to parse series ${doc.id}: ${e.message}")
                            null
                        }
                    } ?: emptyList()
                    
                        android.util.Log.d("ContentRepository", "Loaded ${allSeries.size} series from /series collection")
                        android.util.Log.d("ContentRepository", "Series titles: ${allSeries.map { it.title }}")
                        android.util.Log.d("ContentRepository", "Series thumbnails: ${allSeries.map { it.thumbnailUrl }}")
                    
                    // Only use series if no videos were found
                    if (currentHomeContent.featuredSeries.isEmpty()) {
                        // Show all series in featured only to avoid duplicates
                        val featuredSeries = allSeries.take(10) // Show first 10 as featured
                        val trendingShorts = emptyList<Series>() // Empty to avoid duplicates
                        val newReleases = emptyList<Series>() // Empty to avoid duplicates
                        val premiumSeries = allSeries.filter { it.isPremium }.take(20)
                        
                        android.util.Log.d("ContentRepository", "Displaying all series: ${allSeries.map { it.title }}")
                        
                        // Update home content
                        updateHomeContent(
                            featuredSeries = featuredSeries,
                            trendingShorts = trendingShorts,
                            newReleases = newReleases,
                            premiumSeries = premiumSeries
                        )
                        trySend(currentHomeContent)
                    }
                }
            listeners.add(seriesListener)
            
                // Also check uploads collection for draft content (for testing)
                val uploadsListener = firestore.collection("uploads")
                    .limit(10)
                    .addSnapshotListener(MetadataChanges.INCLUDE) { snapshot, error ->
                    if (error != null) {
                        android.util.Log.e("ContentRepository", "Uploads collection error: ${error.message}")
                        return@addSnapshotListener
                    }
                    
                    val uploads = snapshot?.documents?.mapNotNull { doc ->
                        try {
                            val data = doc.data
                            android.util.Log.d("ContentRepository", "Found upload: ${data?.get("seriesData")?.toString()}")
                            null // Don't process uploads for now, just log them
                        } catch (e: Exception) {
                            android.util.Log.e("ContentRepository", "Failed to parse upload ${doc.id}: ${e.message}")
                            null
                        }
                    } ?: emptyList()
                    
                    android.util.Log.d("ContentRepository", "Found ${uploads.size} uploads in /uploads collection")
                }
            listeners.add(uploadsListener)
            
            
            
            
            // Listen to categories
            val categoriesListener = firestore.collection(CATEGORIES_COLLECTION)
                .addSnapshotListener(MetadataChanges.INCLUDE) { snapshot, error ->
                    if (error != null) {
                        android.util.Log.e("ContentRepository", "Categories error: ${error.message}")
                        return@addSnapshotListener
                    }
                    
                    val categories = snapshot?.documents?.mapNotNull { doc ->
                        try {
                            doc.data?.let { data ->
                                Category(
                                    id = data["id"] as? String ?: "",
                                    name = data["name"] as? String ?: "",
                                    description = data["description"] as? String ?: "",
                                    iconUrl = data["iconUrl"] as? String,
                                    color = data["color"] as? String ?: "#FF6B35",
                                    isActive = data["isActive"] as? Boolean ?: true,
                                    priority = (data["priority"] as? Long)?.toInt() ?: 0
                                )
                            }
                        } catch (e: Exception) {
                            android.util.Log.e("ContentRepository", "Failed to parse category ${doc.id}: ${e.message}")
                            null
                        }
                    }?.filter { category ->
                        // Client-side filtering for active categories
                        category.isActive
                    }?.sortedByDescending { category ->
                        // Client-side sorting by priority
                        category.priority
                    } ?: emptyList()
                    
                    android.util.Log.d("ContentRepository", "Loaded ${categories.size} categories")
                    
                    // Only update categories, don't overwrite series content
                    currentHomeContent = currentHomeContent.copy(categories = categories)
                    trySend(currentHomeContent)
                }
            listeners.add(categoriesListener)
            
        } catch (e: Exception) {
            android.util.Log.e("ContentRepository", "Home content flow error: ${e.message}")
            trySend(HomeContent())
        }
        
        // Let the real-time listeners handle content loading from Firestore
        
        awaitClose {
            listeners.forEach { it.remove() }
        }
    }
    
    // Real-time home content state management
    private var currentHomeContent = HomeContent()
    
    // Force fresh content loading
    fun clearCache() {
        currentHomeContent = HomeContent()
        android.util.Log.d("ContentRepository", "Cache cleared - forcing fresh content load")
    }
    
    private fun updateHomeContent(
        featuredSeries: List<Series> = emptyList(),
        trendingShorts: List<Series> = emptyList(),
        newReleases: List<Series> = emptyList(),
        premiumSeries: List<Series> = emptyList(),
        categories: List<Category> = emptyList()
    ) {
        // Always update with new content, even if empty
        currentHomeContent = currentHomeContent.copy(
            featuredSeries = featuredSeries,
            trendingShorts = trendingShorts,
            newReleases = newReleases,
            premiumSeries = premiumSeries,
            categories = if (categories.isNotEmpty()) categories else currentHomeContent.categories
        )
        
        android.util.Log.d("ContentRepository", "Updated home content: featured=${featuredSeries.size}, trending=${trendingShorts.size}, new=${newReleases.size}, premium=${premiumSeries.size}")
    }
    
    // Get home page content with offline-first approach (one-time fetch)
    suspend fun getHomeContent(): Result<HomeContent> = safeApiCall {
        val featuredVideos = getFeaturedVideos()
        val trendingVideos = getTrendingVideos()
        val newReleases = getNewReleases()
        val premiumVideos = getPremiumVideos()
        
        android.util.Log.d("ContentRepository", "Loaded home content: ${featuredVideos.size} featured, ${trendingVideos.size} trending, ${newReleases.size} new, ${premiumVideos.size} premium")
        
        HomeContent(
            featuredSeries = featuredVideos,
            trendingShorts = trendingVideos,
            newReleases = newReleases,
            premiumSeries = premiumVideos,
            categories = emptyList(), // TODO: Load from categories collection
            continueWatching = emptyList() // TODO: Load from user progress
        )
    }
    
    // Get featured videos
    private suspend fun getFeaturedVideos(): List<Series> {
        return firestore.collection(VIDEOS_COLLECTION)
            .whereEqualTo("status", "published")
            .whereEqualTo("isFeatured", true)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(10)
            .get()
            .await()
            .documents
            .mapNotNull { doc ->
                try {
                    doc.data?.let { Series.fromFirestoreMap(it, doc.id) }
                } catch (e: Exception) {
                    android.util.Log.e("ContentRepository", "Failed to parse featured video ${doc.id}: ${e.message}")
                    null
                }
            }
    }
    
    // Get trending videos
    private suspend fun getTrendingVideos(): List<Series> {
        return firestore.collection(VIDEOS_COLLECTION)
            .whereEqualTo("status", "published")
            .whereEqualTo("isTrending", true)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(20)
            .get()
            .await()
            .documents
            .mapNotNull { doc ->
                try {
                    doc.data?.let { Series.fromFirestoreMap(it, doc.id) }
                } catch (e: Exception) {
                    android.util.Log.e("ContentRepository", "Failed to parse trending video ${doc.id}: ${e.message}")
                    null
                }
            }
    }

    // Get new releases
    private suspend fun getNewReleases(): List<Series> {
        return firestore.collection(VIDEOS_COLLECTION)
            .whereEqualTo("status", "published")
            .whereEqualTo("isNew", true)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(15)
            .get()
            .await()
            .documents
            .mapNotNull { doc ->
                try {
                    doc.data?.let { Series.fromFirestoreMap(it, doc.id) }
                } catch (e: Exception) {
                    android.util.Log.e("ContentRepository", "Failed to parse new release ${doc.id}: ${e.message}")
                    null
                }
            }
    }
    
    // Get premium videos
    private suspend fun getPremiumVideos(): List<Series> {
        return firestore.collection(VIDEOS_COLLECTION)
            .whereEqualTo("status", "published")
            .whereEqualTo("monetization.type", "premium")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(20)
            .get()
            .await()
            .documents
            .mapNotNull { doc ->
                try {
                    doc.data?.let { Series.fromFirestoreMap(it, doc.id) }
                } catch (e: Exception) {
                    android.util.Log.e("ContentRepository", "Failed to parse premium video ${doc.id}: ${e.message}")
                    null
                }
            }
    }
    
    // Get categories
    private suspend fun getCategories(): List<Category> {
        return firestore.collection(CATEGORIES_COLLECTION)
            .get()
            .await()
            .documents
            .mapNotNull { doc ->
                try {
                    doc.data?.let { data ->
                        Category(
                            id = data["id"] as? String ?: "",
                            name = data["name"] as? String ?: "",
                            description = data["description"] as? String ?: "",
                            iconUrl = data["iconUrl"] as? String,
                            color = data["color"] as? String ?: "#FF6B35",
                            isActive = data["isActive"] as? Boolean ?: true,
                            priority = (data["priority"] as? Long)?.toInt() ?: 0
                        )
                    }
                } catch (e: Exception) {
                    android.util.Log.e("ContentRepository", "Failed to parse category ${doc.id}: ${e.message}")
                    null
                }
            }
            .filter { category ->
                // Client-side filtering for active categories
                category.isActive
            }
            .sortedByDescending { category ->
                // Client-side sorting by priority
                category.priority
            }
    }
    
    // Get video with episodes (real-time)
    fun getSeriesWithEpisodesFlow(seriesId: String): Flow<SeriesWithEpisodes?> = callbackFlow {
        val seriesListener = firestore.collection(VIDEOS_COLLECTION)
            .document(seriesId)
            .addSnapshotListener { seriesSnapshot, error ->
                if (error != null) {
                    android.util.Log.e("ContentRepository", "Series error: ${error.message}")
                    trySend(null)
                    return@addSnapshotListener
                }
                
                val series = seriesSnapshot?.data?.let { 
                    try {
                        Series.fromFirestoreMap(it, seriesId)
                    } catch (e: Exception) {
                        android.util.Log.e("ContentRepository", "Failed to parse series ${seriesId}: ${e.message}")
                        null
                    }
                }
                if (series == null) {
                    android.util.Log.w("ContentRepository", "Series not found: $seriesId")
                    trySend(null)
                    return@addSnapshotListener
                }
                
                // For CMS videos, each video is a single episode
                val episode = try {
                    Episode.fromFirestoreMap(seriesSnapshot.data!!)
                } catch (e: Exception) {
                    android.util.Log.e("ContentRepository", "Failed to parse episode for series ${seriesId}: ${e.message}")
                    null
                }
                
                if (episode != null) {
                    trySend(SeriesWithEpisodes(series = series, episodes = listOf(episode)))
                } else {
                    trySend(null)
                }
            }
        
        awaitClose { seriesListener.remove() }
    }
    
    // Get series with episodes (one-time fetch)
    suspend fun getSeriesWithEpisodes(seriesId: String): Result<SeriesWithEpisodes> = safeApiCall {
        android.util.Log.d("ContentRepository", "Loading series with episodes for ID: $seriesId")
        
        // First try to get from /videos collection (CMS primary collection)
        val videoDoc = firestore.collection(VIDEOS_COLLECTION)
            .document(seriesId)
            .get()
            .await()

        if (videoDoc.exists()) {
            android.util.Log.d("ContentRepository", "Found video in /videos collection: $seriesId")
            val videoData = videoDoc.data ?: throw Exception("Video data is null")
            
            val series = try {
                Series.fromFirestoreMap(videoData, seriesId)
            } catch (e: Exception) {
                android.util.Log.e("ContentRepository", "Failed to parse series data: ${e.message}")
                throw Exception("Failed to parse series data")
            }
            
            val episode = try {
                Episode.fromFirestoreMap(videoData)
            } catch (e: Exception) {
                android.util.Log.e("ContentRepository", "Failed to parse episode data: ${e.message}")
                throw Exception("Failed to parse episode data")
            }
            
            android.util.Log.d("ContentRepository", "Loaded series: ${series.title} with video URL: ${episode.videoUrl}")
            return@safeApiCall SeriesWithEpisodes(series = series, episodes = listOf(episode))
        }
        
        // Fallback to /series collection (old structure)
        android.util.Log.d("ContentRepository", "Video not found in /videos, trying /series collection")
        val seriesDoc = firestore.collection(SERIES_COLLECTION)
            .document(seriesId)
            .get()
            .await()

        if (!seriesDoc.exists()) {
            android.util.Log.w("ContentRepository", "Series not found in any collection: $seriesId")
            throw Exception("Series not found")
        }

        val seriesData = seriesDoc.data ?: throw Exception("Series data is null")
        val series = try {
            Series.fromFirestoreMap(seriesData, seriesId)
        } catch (e: Exception) {
            android.util.Log.e("ContentRepository", "Failed to parse series data: ${e.message}")
            throw Exception("Failed to parse series data")
        }
        
        // Get all episodes for this series from /episodes collection
        val episodesSnapshot = firestore.collection(EPISODES_COLLECTION)
            .whereEqualTo("seriesId", seriesId)
            .get()
            .await()
        
        val episodes = episodesSnapshot.documents.mapNotNull { episodeDoc ->
            try {
                val episodeData = episodeDoc.data ?: return@mapNotNull null
                Episode.fromFirestoreMap(episodeData)
            } catch (e: Exception) {
                android.util.Log.e("ContentRepository", "Failed to parse episode ${episodeDoc.id}: ${e.message}")
                null
            }
        }.filter { episode ->
            // Client-side filtering for active episodes
            episode.isActive
        }.sortedBy { episode ->
            // Client-side sorting by episode number
            episode.episodeNumber
        }
        
        // If no episodes found in /episodes collection, create one from the series data
        val finalEpisodes = if (episodes.isEmpty()) {
            android.util.Log.d("ContentRepository", "No episodes found in /episodes collection, creating from series data")
            try {
                listOf(Episode.fromFirestoreMap(seriesData))
            } catch (e: Exception) {
                android.util.Log.e("ContentRepository", "Failed to parse episode from series data: ${e.message}")
                throw Exception("Failed to parse episode data")
            }
        } else {
            episodes
        }
        
        android.util.Log.d("ContentRepository", "Loaded series: ${series.title} with ${finalEpisodes.size} episodes")
        SeriesWithEpisodes(series = series, episodes = finalEpisodes)
    }
    
    // Search content with pagination
    suspend fun searchContent(
        query: String, 
        limit: Int = 20,
        lastDocument: com.google.firebase.firestore.DocumentSnapshot? = null
    ): Result<PaginatedResult<Series>> = safeApiCall {
        var queryBuilder = firestore.collection(VIDEOS_COLLECTION)
            .whereEqualTo("status", "published")
            .orderBy("details.title")
            .limit(limit.toLong())
        
        // Add pagination cursor
        if (lastDocument != null) {
            queryBuilder = queryBuilder.startAfter(lastDocument)
        }
        
        val querySnapshot = queryBuilder.get().await()
        
        val results = querySnapshot.documents
            .mapNotNull { doc ->
                try {
                    doc.data?.let { Series.fromFirestoreMap(it, doc.id) }
                } catch (e: Exception) {
                    android.util.Log.e("ContentRepository", "Failed to parse search result ${doc.id}: ${e.message}")
                    null
                }
            }
            .filter { series ->
                series.title.contains(query, ignoreCase = true) ||
                series.description.contains(query, ignoreCase = true) ||
                series.category.contains(query, ignoreCase = true) ||
                series.genres.any { it.contains(query, ignoreCase = true) }
            }
        
        android.util.Log.d("ContentRepository", "Search results: ${results.size} for query: $query")
        
        PaginatedResult(
            items = results,
            hasMore = querySnapshot.documents.size == limit,
            nextPageToken = querySnapshot.documents.lastOrNull()?.id
        )
    }
    
    // Get content by category with pagination
    suspend fun getContentByCategory(
        category: String,
        limit: Int = 20,
        lastDocument: com.google.firebase.firestore.DocumentSnapshot? = null
    ): Result<PaginatedResult<Series>> = safeApiCall {
        var queryBuilder = firestore.collection(VIDEOS_COLLECTION)
            .whereEqualTo("status", "published")
            .whereEqualTo("details.category", category)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(limit.toLong())
        
        // Add pagination cursor
        if (lastDocument != null) {
            queryBuilder = queryBuilder.startAfter(lastDocument)
        }
        
        val querySnapshot = queryBuilder.get().await()
        
        val results = querySnapshot.documents.mapNotNull { doc ->
            try {
                doc.data?.let { Series.fromFirestoreMap(it) }
            } catch (e: Exception) {
                android.util.Log.e("ContentRepository", "Failed to parse category result ${doc.id}: ${e.message}")
                null
            }
        }
        
        android.util.Log.d("ContentRepository", "Category results: ${results.size} for category: $category")
        
        PaginatedResult(
            items = results,
            hasMore = querySnapshot.documents.size == limit,
            nextPageToken = querySnapshot.documents.lastOrNull()?.id
        )
    }
    
    // Get all shorts with pagination
    suspend fun getAllShorts(
        limit: Int = 20,
        lastDocument: com.google.firebase.firestore.DocumentSnapshot? = null
    ): Result<PaginatedResult<Series>> = safeApiCall {
        var queryBuilder = firestore.collection(VIDEOS_COLLECTION)
            .whereEqualTo("status", "published")
            .whereEqualTo("details.category", "shorts")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(limit.toLong())
        
        // Add pagination cursor
        if (lastDocument != null) {
            queryBuilder = queryBuilder.startAfter(lastDocument)
        }
        
        val querySnapshot = queryBuilder.get().await()
        
        val results = querySnapshot.documents.mapNotNull { doc ->
            try {
                doc.data?.let { Series.fromFirestoreMap(it) }
            } catch (e: Exception) {
                android.util.Log.e("ContentRepository", "Failed to parse shorts result ${doc.id}: ${e.message}")
                null
            }
        }
        
        android.util.Log.d("ContentRepository", "Shorts results: ${results.size}")
        
        PaginatedResult(
            items = results,
            hasMore = querySnapshot.documents.size == limit,
            nextPageToken = querySnapshot.documents.lastOrNull()?.id
        )
    }

    // Get content by type with pagination
    suspend fun getContentByType(
        type: ContentType,
        limit: Int = 20,
        lastDocument: com.google.firebase.firestore.DocumentSnapshot? = null
    ): Result<PaginatedResult<Series>> = safeApiCall {
        var queryBuilder = firestore.collection(VIDEOS_COLLECTION)
            .whereEqualTo("status", "published")
            .whereEqualTo("details.category", type.name.lowercase())
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(limit.toLong())
        
        // Add pagination cursor
        if (lastDocument != null) {
            queryBuilder = queryBuilder.startAfter(lastDocument)
        }
        
        val querySnapshot = queryBuilder.get().await()
        
        val results = querySnapshot.documents.mapNotNull { doc ->
            try {
                doc.data?.let { Series.fromFirestoreMap(it) }
            } catch (e: Exception) {
                android.util.Log.e("ContentRepository", "Failed to parse type result ${doc.id}: ${e.message}")
                null
            }
        }
        
        android.util.Log.d("ContentRepository", "Type results: ${results.size} for type: ${type.name}")
        
        PaginatedResult(
            items = results,
            hasMore = querySnapshot.documents.size == limit,
            nextPageToken = querySnapshot.documents.lastOrNull()?.id
        )
    }
    
    // FIXED: Add search-related methods for SearchViewModel
    suspend fun getPopularSearches(): List<String> {
        return try {
            // Get popular search terms from analytics collection
            val snapshot = firestore.collection("analytics")
                .document("search_terms")
                .get()
                .await()
            
            val data = snapshot.data
            if (data != null) {
                (data["popular"] as? List<String>) ?: emptyList()
            } else {
                // Fallback to default popular searches
                listOf("Comedy", "Drama", "Action", "Romance", "Thriller", "Horror", "Sci-Fi", "Documentary", "Animation")
            }
        } catch (e: Exception) {
            android.util.Log.e("ContentRepository", "Failed to get popular searches: ${e.message}")
            emptyList()
        }
    }
    
    suspend fun getRecentSearches(): List<String> {
        return try {
            // Get recent searches from local storage (implement with SharedPreferences)
            // For now, return empty list - this should be implemented with local storage
            emptyList()
        } catch (e: Exception) {
            android.util.Log.e("ContentRepository", "Failed to get recent searches: ${e.message}")
            emptyList()
        }
    }
    
}